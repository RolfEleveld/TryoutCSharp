﻿//|---------------------------------------------------------------|
//|                   RESTFUL SIGNALR SERVICE                     |
//|---------------------------------------------------------------|
//|                     Developed by Wonde Tadesse                |
//|                        Copyright ©2015 - Present              |
//|---------------------------------------------------------------|
//|                   RESTFUL SIGNALR SERVICE                     |
//|---------------------------------------------------------------|
using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Dynamic;

using CommonLibrary;
using RESTfulSignalRService.MessageBroadCaster;
using RESTfulSignalRService.Interfaces;


namespace RESTfulSignalRService.SignalRHubs
{
    /// <summary>
    /// BroadCastHub class
    /// </summary>
    public class BroadCastHub : Hub
    {
        #region Constructor

        /// <summary>
        /// BroadCastHub class
        /// </summary>
        public BroadCastHub(IBroadCast broadCast)
        {
            if (broadCast == null)
                throw new ArgumentNullException("BroadCast object is null !");

            BeginBroadCast(broadCast); // This will avoid calling to initialize a hub in message broadcaster client
        }

        #endregion

        #region Private Methods 

        /// <summary>
        /// Begin broadCast message
        /// </summary>
        /// <param name="broadCast">IBroadCast value</param>
        private void BeginBroadCast(IBroadCast broadCast)
        {
            // Register/Attach broadcast listener event
            broadCast.MessageListened += (sender, broadCastArgs)
                =>
                {
                    RegisterMessageEvents(broadCastArgs);
                };

            // Unregister/detach broadcast listener event
            broadCast.MessageListened -= (sender, broadCastArgs)
               =>
               {
                   RegisterMessageEvents(broadCastArgs);
               };
        }

        /// <summary>
        /// Register broadcasted message to SignalR events
        /// </summary>
        /// <param name="broadCastArgs">BroadCastEventArgs value</param>
        private void RegisterMessageEvents(BroadCastEventArgs broadCastArgs)
        {
            if (broadCastArgs != null)
            {
                MessageRequest messageRequest = broadCastArgs.MessageRequest;

                switch (messageRequest.EventName)
                {
                    case EventNameEnum.ON_MESSAGE_LISTENED:
                        Clients.Caller.onMessageListened(messageRequest.Message);
                        break;
                    case EventNameEnum.ON_INSERTED:
                        Clients.Caller.onInserted(messageRequest.Message);
                        break;
                    case EventNameEnum.ON_DELETED:
                        Clients.Caller.onDeleted(messageRequest.Message);
                        break;
                    case EventNameEnum.ON_UPDATED:
                        Clients.Caller.onUpdated(messageRequest.Message);
                        break;

                    /*
                                     
                     * Case more event name upon future design agreement
                                     
                     */

                    default:
                        Clients.Caller.onException("Unknown or empty event name is requested!"); // Goes to the listener
                        throw new Exception("Unknown or empty event name is requested!"); // Goes to the broadcaster
                }

            }
        }

        #endregion
    }
}