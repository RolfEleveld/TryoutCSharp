﻿//|---------------------------------------------------------------|
//|                  MESSAGE LISTENER WPF APP                     |
//|---------------------------------------------------------------|
//|                     Developed by Wonde Tadesse                |
//|                        Copyright ©2015 - Present              |
//|---------------------------------------------------------------|
//|                  MESSAGE LISTENER WPF APP                     |
//|---------------------------------------------------------------|
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using SignalRBroadCastListener.MessageListener;


namespace MessageListenerWPFApp.Business.Interfaces
{
    /// <summary>
    /// DataBase Hub Listener interface
    /// </summary>
    public interface IDBListener
    {
        #region Public Properties

        /// <summary>
        /// Get Insert Listener
        /// </summary>
        BroadCastListener InsertListener { get; }

        /// <summary>
        /// Get Update Listener
        /// </summary>
        BroadCastListener UpdateListener { get; }

        /// <summary>
        /// Get Delete Listener
        /// </summary>
        BroadCastListener DeleteListener { get; }

        #endregion
    }
}