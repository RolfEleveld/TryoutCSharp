﻿//|---------------------------------------------------------------|
//|                  MESSAGE LISTENER WPF APP                     |
//|---------------------------------------------------------------|
//|                     Developed by Wonde Tadesse                |
//|                        Copyright ©2015 - Present              |
//|---------------------------------------------------------------|
//|                  MESSAGE LISTENER WPF APP                     |
//|---------------------------------------------------------------|
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MessageListenerWPFApp.VM
{
    /// <summary>
    /// Observable ConfigurationLookUps
    /// </summary>
    public class ConfigurationLookUps :
        ObservableCollection<ConfigurationLookupVM>
    {
    }
}
