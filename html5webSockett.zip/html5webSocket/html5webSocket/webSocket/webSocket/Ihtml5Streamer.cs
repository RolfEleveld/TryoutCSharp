﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace wsSocket
{
    interface Ihtml5Streamer
    {
        void setwsSocket(html5Stream sockStream);
    }
}
