﻿/*
  Copyright (C) Bharath K A

  Permission is hereby granted, free of charge, to any person obtaining a copy of this 
  software and associated documentation files (the "Software"), to deal in the Software
  without restriction, including without limitation the rights to use, copy, modify, 
  merge, publish, distribute, sublicense, and/or sell copies of the Software, and to 
  permit persons to whom the Software is furnished to do so, subject to the following conditions:

  The above copyright notice and this permission notice shall be included in all copies or 
  substantial portions of the Software.

  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT
  NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
  NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
  DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, 
  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
*/


using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;

namespace wsSocket
{
  public class html5Stream
  {
    private Socket serverSocket;
    private string uniqueID = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";
    private SHA1 sha1Crypto = SHA1CryptoServiceProvider.Create();
    private object lockObj = new object();
    private StringBuilder streamData = new StringBuilder();
    private AutoResetEvent eventDataAvailable = new AutoResetEvent(false);
    private bool shutDown = false;
    private HashSet<Socket> socketsToUpdate = new HashSet<Socket>();
    private fastParser fastPrsr = new fastParser();


    public bool AutoDemo
    {
      set;
      get;
    }

    public void startServer(string endPt = "", bool demo = false)
    {
      AutoDemo = demo;
      serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.IP);
      serverSocket.Bind(new IPEndPoint(IPAddress.Any, 8080));
      serverSocket.Listen(256);

      System.Console.WriteLine("Press Ctrl + c to stop server");
      int counter = 0;
      ThreadPool.QueueUserWorkItem(new WaitCallback(publishAll));

      while (!Console.KeyAvailable)
      {
        Socket ws = serverSocket.Accept();
        ThreadPool.QueueUserWorkItem(new WaitCallback(OnAcceptConnection), ws);

        counter++;
      }

      shutDown = true;
      eventDataAvailable.Set();

      System.Console.ReadKey();
    }

    public void setStreamData(string data)
    {
      lock (lockObj)
      {
        streamData.Clear();
        streamData.Append(data);
      }

      eventDataAvailable.Set();
    }

    private void subscribe(Socket s)
    {
      lock (lockObj)
      {
        socketsToUpdate.Add(s);
      }
    }

    private void unSubscribe(Socket s)
    {
      lock (lockObj)
      {
        socketsToUpdate.Remove(s);
      }
    }

    private void publishAll(object dummy)
    {
      byte[] byteToSend = null;

      List<Socket> socksToRemove = new List<Socket>();
      while(!shutDown)
      {
        bool dataReceived = eventDataAvailable.WaitOne(1000);
        if (shutDown) break;
        if (dataReceived)
        {
          encodeData(getStreamData(), ref byteToSend);
          lock (lockObj)
          {
            HashSet<Socket>.Enumerator enumSockets = socketsToUpdate.GetEnumerator();
            SocketAsyncEventArgs sendData = new SocketAsyncEventArgs();
            sendData.SetBuffer(byteToSend, 0, byteToSend.Length);
            while (enumSockets.MoveNext())
            {
              try
              {
                if (enumSockets.Current.Available == 0 && enumSockets.Current.Poll(1000, SelectMode.SelectRead)) throw new Exception("Client Closed Connection");
                enumSockets.Current.SendAsync(sendData);
              }
              catch (Exception ex)
              {
                System.Console.WriteLine("Socket Closed: {0}", enumSockets.Current.RemoteEndPoint);

                Trace.TraceError("Socket Error on : {0}", enumSockets.Current.RemoteEndPoint, ex.Message);
                socksToRemove.Add(enumSockets.Current);
              }
            }

            foreach (Socket socket in socksToRemove)
            {
                unSubscribe(socket);
            }
            socksToRemove.Clear();
          }

          if (AutoDemo)
          {
              System.Threading.Thread.Sleep(1700);
              setStreamData(getRandomNumbers());
          }

        }

      }
    }

    private string processStreamData()
    {
        StringBuilder retVal = new StringBuilder();

        string[] dataOrig = streamData.ToString().Split(',').Select(s => s.Trim()).ToArray();
        string[] data;

        int rows = 0, cols = 0;
        HashSet<int> computedCols = new HashSet<int>();

        if (dataOrig.Length > 4)
        {
            rows = int.Parse(dataOrig[2]);
            cols = int.Parse(dataOrig[3]);
            retVal.AppendFormat("{0}, {1}, {2}, {3}", dataOrig[0], dataOrig[1], dataOrig[2], dataOrig[3]);
            data = new string[rows * cols];

            int dataPos = 4;

            Dictionary<string, string> formulaCols = new Dictionary<string,string>();
            Dictionary<string, List<int>> formulaDepend = new Dictionary<string, List<int>>();
            for (int colCount = 0; colCount < cols && dataOrig.Length > colCount; colCount++)
            {
                string title = dataOrig[dataPos + colCount];
                data[colCount] = title;

                if (dataOrig[dataPos + colCount].Contains("="))
                {
                    computedCols.Add(colCount);
                    title = dataOrig[dataPos + colCount].Substring(0, dataOrig[dataPos + colCount].IndexOf("="));
                    string formula = dataOrig[dataPos + colCount].Substring(dataOrig[dataPos + colCount].IndexOf("=") + 1, dataOrig[dataPos + colCount].Length - dataOrig[dataPos + colCount].IndexOf("=") - 1);
                    formulaCols.Add(dataOrig[dataPos + colCount], title);
                    fastPrsr.addNewFormula(title, formula);

                    List<int> colDepend = new List<int>();
                    for (int colCounter = 0; colCounter < cols; colCounter++)
                    {
                        if (formula.Contains(dataOrig[dataPos + colCounter]))
                        {
                            colDepend.Add(colCounter);
                        }
                    }
                    formulaDepend.Add(dataOrig[dataPos + colCount], colDepend);

                }
                retVal.AppendFormat(",{0}", title);
                
            }

            for (int row = 1; row < rows; row++)
            {
                for (int col = 0; col < cols; col++)
                {
                    if (computedCols.Contains(col))
                    {
                        data[row * cols + col] = "0";
                    }
                    else
                    {
                        data[row * cols + col] = dataOrig[dataPos + row * cols + col];
                    }
                }
            }


            for (int rowCount = 1; rowCount < rows; rowCount++)
            {
                for (int colCount = 0; colCount < cols && data.Length >  rowCount * cols + colCount; colCount++)
                {
                    string dataToAdd = string.Empty;
                    if (data[colCount].Contains("="))
                    { 
                        string title;
                        if (formulaCols.TryGetValue(data[colCount], out title))
                        {
                            List<int> depends;
                            if (formulaDepend.TryGetValue(data[colCount], out depends))
                            {
                                Dictionary<string, double> dependValues = new Dictionary<string, double>();
                                foreach (int depend in depends)
                                {
                                    double value;
                                    if (double.TryParse(data[rowCount * cols + depend], out value))
                                    {
                                        dependValues.Add(data[depend], value);
                                    }
                                    else
                                    {
                                        dependValues.Add(data[depend], 0.0);
                                    }
                                }

                                dataToAdd = fastPrsr.computeFormula(title, dependValues).ToString();

                            }
                        }
                    }
                    else
                    {
                        dataToAdd = data[rowCount * cols + colCount];
                    }
                    retVal.AppendFormat(",{0}", dataToAdd);

                }
            }
        }

        return retVal.ToString();
    }

    private string getStreamData()
    {
      string retVal;

      lock (lockObj)
      {
        //retVal = streamData.ToString();
          retVal = processStreamData();
      }

      return retVal;
    }

    private string getStrFromByte(byte[] bytes, int sizeLen)
    {
      return Encoding.UTF8.GetString(bytes, 0, sizeLen);
    }

    private string getKeyFromHeader(string header)
    {
      string keyStr = header.Replace("ey:", "`")
                             .Split('`')[1]
                             .Replace("\r", "").Split('\n')[0]
                             .Trim();
      return keyStr;
    }

    private void prepareClientResponse(string header, ref byte[] retVal)
    {

      string key = getKeyFromHeader(header);
      string newKey = key + uniqueID;

      byte[] hashBytesToSend = sha1Crypto.ComputeHash(Encoding.ASCII.GetBytes(newKey));

      string respkey = Convert.ToBase64String(hashBytesToSend);

      string clientResp = "HTTP/1.1 101 Switching Protocols\r\n"
                         + "Upgrade: websocket\r\n"
                         + "Connection: Upgrade\r\n"
                         + "Sec-WebSocket-Accept: " + respkey + "\r\n\r\n";
      //+"Sec-WebSocket-Protocol: chat, superchat\r\n" 
      //+ "Sec-WebSocket-Version: 13\r\n";

      Trace.TraceInformation("prepareClientResponse -- Sending Response to Client: {0}", clientResp);

      retVal = Encoding.UTF8.GetBytes(clientResp);

    }

    private string decodeData(byte[] data)
    {
        int length = data.Length;
        byte dataType = data[0];
        byte[] mask;

        Trace.TraceInformation("Data Type = {0}", dataType);

        byte dataLength = data[1];
        int keyIndex = 0;
        int finalLength = 0;

        int lengthDataByte = 0;

        if (dataLength - 128 <= 125)
        {
            lengthDataByte = dataLength - 128;
            keyIndex = 2;
            finalLength = lengthDataByte + 6;
        }
        else if (dataLength - 128 == 126)
        {
            if (length < 4) return string.Empty;
            lengthDataByte = BitConverter.ToInt16(new byte[] { (byte)data[3], (byte)data[2] }, 0);
            keyIndex = 4;
            finalLength = lengthDataByte + 8;
        }
        else
        {
            if (length < 10) return string.Empty;
            lengthDataByte = (int)BitConverter.ToInt64(new byte[] { data[9], data[8], data[7], data[6], data[5], data[4], data[3], data[2] }, 0);
            keyIndex = 10;
            finalLength = lengthDataByte + 14;
        }

        if (finalLength > length) return string.Empty;

        mask = new byte[] { data[keyIndex], data[keyIndex + 1], data[keyIndex + 2], data[keyIndex + 3] };

        byte[] buffer = new byte[finalLength - (keyIndex + 4)];

        for (int counter = 0; counter + keyIndex + 4 < finalLength; counter++)
        {
            buffer[counter] = (byte)((data[counter + keyIndex + 4]) ^ (mask[counter % 4]));
        }
        return Encoding.UTF8.GetString(buffer);
      //byte dataType = data[0];
      //byte[] mask = new byte[4];

      //Trace.TraceInformation("Data Type = {0}", dataType);

      //byte dataLength = (byte)(data[1] & (byte)0x80);

      //int lengthDataByte = 0;

      //if (dataLength == 126)
      //{
      //  lengthDataByte = 2;
      //}
      //else if (dataLength == 127)
      //{
      //  lengthDataByte = 8;
      //}
      //else
      //{
      //  lengthDataByte = data[1] & 0x7f;
      //}

      //int finalLength = 0;

      //if (lengthDataByte == 2 || lengthDataByte == 8)
      //{
      //  for (int counter = 0; counter < lengthDataByte; counter++)
      //  {
      //    finalLength <<= data[2 + counter];
      //  }
      //}
      //else
      //{
      //  finalLength = lengthDataByte;
      //  lengthDataByte = 0;
      //}

      //mask[0] = data[2 + lengthDataByte];
      //mask[1] = data[2 + lengthDataByte + 1];
      //mask[2] = data[2 + lengthDataByte + 2];
      //mask[3] = data[2 + lengthDataByte + 3];

      //byte[] buffer = new byte[finalLength];

      //for (int counter = 0; counter < finalLength; counter++)
      //{
      //  buffer[counter] = (byte)((data[2 + lengthDataByte + 4 + counter]) ^ (mask[counter % 4]));
      //}

      //return Encoding.UTF8.GetString(buffer);

    }

    private void encodeData(string data, ref byte[] dataByte)
    {
      int lengthOfData = data.Length;
      int rawByteStart = 2;

      if (lengthOfData <= 125)
      {
        dataByte = new byte[lengthOfData + 2];
        dataByte[0] = 129;
        dataByte[1] = (byte)lengthOfData;

      }
      else if (lengthOfData > 125 && lengthOfData <= 65535)
      {
        dataByte = new byte[lengthOfData + 4];
        dataByte[0] = 129;
        dataByte[1] = 126;
        dataByte[2] = (byte)((lengthOfData >> 8) & 0xff);
        dataByte[3] = (byte)((lengthOfData) & 0xff);
        rawByteStart = 4;
      }
      else
      {
        dataByte = new byte[lengthOfData + 10];
        dataByte[0] = 129;

        dataByte[2] = (byte)((lengthOfData >> 56) & 255);
        dataByte[3] = (byte)((lengthOfData >> 48) & 255);
        dataByte[4] = (byte)((lengthOfData >> 40) & 255);
        dataByte[5] = (byte)((lengthOfData >> 32) & 255);
        dataByte[6] = (byte)((lengthOfData >> 24) & 255);
        dataByte[7] = (byte)((lengthOfData >> 16) & 255);
        dataByte[8] = (byte)((lengthOfData >> 8) & 255);
        dataByte[9] = (byte)((lengthOfData) & 255);
        rawByteStart = 10;
      }

      Encoding.UTF8.GetBytes(data, 0, data.Length, dataByte, rawByteStart);
    }

    private string getRandomNumbers()
    {
      var r = new Random();
      StringBuilder sbRet = new StringBuilder();
      int width = 800;
      int height = 350;
      int rowNum = 10;
      int colNum = 10;

      sbRet.AppendFormat("{0},{1},{2},{3}", width, height, rowNum + 1, colNum);

      for (int col = 0; col < colNum; col++)
      {
        sbRet.Append(",");
        sbRet.AppendFormat("Colmn{0}", col);

      }

      for (int row = 0; row < rowNum; row++)
      {
        for (int col = 0; col < colNum; col++)
        {
          sbRet.Append(",");
          sbRet.AppendFormat("{0}", (float)r.Next(100000) / (float)100.0);

        }
      }

      return sbRet.ToString();
    }


    private void OnAcceptConnection(object param)
    {
      byte[] buffer = new byte[1024];
      byte[] sendBuffer = null;
      Socket client = (Socket)param;
      string headerResponse = string.Empty;

      try
      {
        if (serverSocket != null && serverSocket.IsBound)
        {
          int rcvBytes = client.Receive(buffer);
          headerResponse = getStrFromByte(buffer, rcvBytes);

          if (client != null)
          {
            prepareClientResponse(headerResponse, ref sendBuffer);
            client.Send(sendBuffer);

            rcvBytes = client.Receive(buffer);
            string dataFromClient = decodeData(buffer);
            Trace.TraceInformation("Data from Client: {0}", dataFromClient);

            Trace.TraceInformation("OnAcceptConnection -- Received {0} bytes: {1}", rcvBytes, dataFromClient);
            subscribe(client);

            System.Console.WriteLine("Serving Client # {0}", System.Threading.Thread.CurrentThread.ManagedThreadId);

            eventDataAvailable.Set();
                // If Active Client connection management is not required the below lines can be commented.  
                //while (true) 
                //{
                //  if (shutDown) return;
                //  Thread.Sleep(1000);
                //    if (client.Available == 0 && client.Poll(1000, SelectMode.SelectRead)) throw new Exception("Client Closed Connection");
                //}
          }
        }
        else
        {
          Trace.TraceError("Error: ServerSocket is NULL or IsBount = false");
        }
      }
      catch (Exception ex)
      {
        Trace.TraceError("Error: Exception: {0}", ex.Message);
      }
      //finally
      //{
      //  unSubscribe(client);
      //  System.Console.WriteLine("Client Closed # {0}", System.Threading.Thread.CurrentThread.ManagedThreadId);
      //  System.Console.WriteLine("Connection Closed");
      //  client.Close();
      //}
 
    }
  }
}
