﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.IO;


namespace wsSocket
{
    public class fileStreamer : Ihtml5Streamer
    {
        private html5Stream htmlStrm;
        private string fileName;
        private FileSystemWatcher fileWatch;
        private int timeToWait = 200;
        private AutoResetEvent eventFileChanged = new AutoResetEvent(false);
        private bool fileChanged = false;
        private bool shutdown = false;

        public void setwsSocket(html5Stream sockStream)
        {
            htmlStrm = sockStream; 
        }

        public fileStreamer(string filePath)
        {
            fileName = filePath;
            string dirName = Path.GetDirectoryName(fileName);
            string file = Path.GetFileName(filePath);
            if (dirName.Length == 0)
            {
                dirName = Directory.GetCurrentDirectory();
            }
            fileWatch = new FileSystemWatcher(dirName);
            fileWatch.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite | NotifyFilters.LastAccess;
            fileWatch.Filter = Path.GetFileName(file);
            fileWatch.Changed += fileWatch_Changed;
            ThreadPool.QueueUserWorkItem(new WaitCallback(watchFile));
            fileWatch.EnableRaisingEvents = true;
        }

        public void shutDown()
        {
            shutdown = true;
        }

        private void streamData()
        {
            StringBuilder sbStream = new StringBuilder();

            string[] fileStr = File.ReadAllLines(fileName);
            int noOfRows = fileStr.Count();
            int noOfCols = 0;
            if (noOfRows > 0)
            {
                noOfCols = fileStr[0].Split(',').Count();
            }

            if (noOfRows > 0)
            {
                string strToStream = File.ReadAllText(fileName).Replace("\r\n", ",").Replace("\t","");
                sbStream.Clear();
                sbStream.AppendFormat("{0},{1},{2},{3},{4}", -1, -1, noOfRows, noOfCols, strToStream);
            }

            htmlStrm.setStreamData(sbStream.ToString());
        }

        public void watchFile(object dummy)
        {
            streamData();
            while (!shutdown)
            {
                bool eventSet = eventFileChanged.WaitOne(timeToWait);
                if (!eventSet && fileChanged)
                {
                    streamData();

                    fileChanged = false;
                }
            }
        }

        void fileWatch_Changed(object sender, FileSystemEventArgs e)
        {
            fileChanged = true;
            eventFileChanged.Set();
        }
    }
}
