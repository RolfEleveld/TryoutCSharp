﻿

function draw(data, txtColorArr, txtFontArr, hdrColor, hdrFont)
{

    var rows = data[2];
    var cols = data[3];
    var dataStart = 4;

    var element = document.getElementById("testCanvas");
    var dWidth = element.width;
    var dHeight = element.height;

    //console.log(, element.height);

    //if (dWidth == -1 || dHeight == -1)
    //{
    //    dWidth = element.width;
    //    dHeight = element.height;
    //    console.log("Setting element width and height");
    //}
    //else
    //{
    //    element.width = dWidth;
    //    element.height = dHeight;
    //}

    var ht = element.clientHeight;
    var width = element.clientWidth;
    var gctxt = element.getContext("2d");

    var grdnt = gctxt.createLinearGradient(0, 0, 0, ht);
    grdnt.addColorStop(0, "#8FBC8F");
    grdnt.addColorStop(0.1, "#FFFACD");
    
    grdnt.addColorStop(1, "#8FBC8F");
    gctxt.fillStyle = grdnt;
    gctxt.fillRect(0, 0, dWidth, dHeight);

    gctxt.beginPath();
    gctxt.strokeStyle = 'gray';
    gctxt.lineWidth = 3;
    gctxt.rect(0, 0, dWidth, dHeight);
  
    gctxt.shadowColor = "#999";
    gctxt.shadowBlur = 20;
    gctxt.shadowOffsetX = 15;
    gctxt.shadowOffsetY = 15;
    gctxt.fill();
    gctxt.stroke();

    var colSize = dWidth / cols;
    var rowSize = dHeight / rows;
    gctxt.shadowOffsetX = 2;
    gctxt.shadowOffsetY = 2;
    for (var count = colSize; count < dWidth; count += colSize)
    {
        gctxt.beginPath();
        gctxt.strokeStyle = 'gray';
        gctxt.lineWidth = 1;
        gctxt.moveTo(count, 0);
        gctxt.lineTo(count, dHeight);
        gctxt.stroke();
    }

    for (var count = rowSize; count < dHeight; count += rowSize)
    {
        gctxt.beginPath();
        gctxt.strokeStyle = 'gray';
        gctxt.lineWidth = 1;
        gctxt.moveTo(0, count);
        gctxt.lineTo(dWidth, count);

        gctxt.stroke();
    }

    var colMid = colSize / 2;
    var rowMid = rowSize / 2;
    var fontCount = 0;
    gctxt.shadowColor = "#999";
    gctxt.shadowOffsetX = 0;
    gctxt.shadowOffsetY = 0;
    for (var rowCount = 0; rowCount < rows * rowSize && dataStart < data.length; rowCount += rowSize)
    {
        for (var colCount = 0; colCount < cols * colSize && dataStart < data.length && cols * colSize - colCount >= colSize; colCount += colSize)
        {
            if (rowCount == 0)
            {
                gctxt.fillStyle = hdrColor;
                gctxt.font = hdrFont;
            }
            else
            {
                gctxt.fillStyle = txtColorArr[fontCount];
                gctxt.font = txtFontArr[fontCount];
            }
            
            gctxt.textAlign = 'center';
            gctxt.textBaseline = 'middle';
			console.log("Data to print = ", data[dataStart]);
            gctxt.fillText(data[dataStart], colCount + colMid, rowCount + rowMid);
            dataStart++;
            fontCount++;
        }
    }
    
}

var gPrevCache = [0,0,0,0];

function drawGrid(arr)
{
    var hdrColor = 'black';
    var hdrFont = 'bold 12px Times';

    var textColor = 'black';
    var textFont = '12px Open Sans';
    var headerSize = 4;
    var txtColorArr = [];
    var txtFontArr = [];

    for (var count = 0; count < arr.length; count++)
    {
        if (Number(gPrevCache[count]) < Number(arr[headerSize + count]))
        {
            txtColorArr[count] = 'green';
            txtFontArr[count] = 'bold 12px Open Sans';
        }
        else if (Number(gPrevCache[count]) > Number(arr[headerSize + count]))
        {
            txtColorArr[count] = 'red';
            txtFontArr[count] = 'bold 12px Open Sans';
        }
        else
        {
            txtColorArr[count] = textColor;
            txtFontArr[count] = textFont;
        }
    }
    draw(arr, txtColorArr, txtFontArr, hdrColor, hdrFont);

    setTimeout(function ()
    {
        for (var count = 0; count < arr.length; count++)
        {
            txtColorArr[count] = textColor;
            txtFontArr[count] = textFont;
            gPrevCache[count] = arr[headerSize + count];
        }
        draw(arr, txtColorArr, txtFontArr, hdrColor, hdrFont);
    }, 700);

}

function drawG()
{
    var arr = [800, 180, 5, 5, 100, 99, 98, 97, 9564, 100, 99, 98, 97, 9564, 100, 99, 98, 97, 9569, 100, 99, 98, 97, 9565, 100, 99, 98, 97, 9569];
    drawGrid(arr);
}

function connect()
{
    var ws = new WebSocket("ws://localhost:8080/service");
    ws.onopen = function()
    {
        console.log("About to send data");
        ws.send("Ready"); // I WANT TO SEND THIS MESSAGE TO THE SERVER!!!!!!!!
        console.log("Message sent!");
    };

    ws.onmessage = function(evt)
    {
        console.log("About to receive data");
        var received_msg = evt.data;
        var tempArr = [];
        var strArr = [];
        tempArr = received_msg.split(",");
        console.log("Size of Array = ", tempArr.length);
        console.log("Array = ", received_msg );

    
        drawGrid(tempArr);
        console.log("Message received ");
    };

    ws.onclose = function()
    {
        // websocket is closed.
        console.log("Connection is closed...");
    };
};

