﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wsSocket;

namespace testHtmlWebSocket
{
    class Program
    {
        static void Main(string[] args)
        {
//          string data = @"-1,-1, 4,5, 
//                        Item_1, Item_2, Item_3, Computed1 = Item_1 + Item_2, Computed2 = Item_2+ Item_3, 
//                        1.12,2.24,3.12,,,
//                        6.83,7.17,8.14,,,
//                        9.11,11.11,0.21,,,
//                        3.12,17.14,5.21,,,";
//          wSock.setStreamData(data);
                    
            html5Stream wSock = new html5Stream();
            fileStreamer fileStrmr = new fileStreamer(@"test.csv");
            fileStrmr.setwsSocket(wSock);
            wSock.startServer("", false);    
        }
    }
}
